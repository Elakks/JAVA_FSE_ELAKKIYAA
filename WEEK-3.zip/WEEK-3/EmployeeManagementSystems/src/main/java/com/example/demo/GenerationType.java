package com.example.demo;

public enum GenerationType {
	IDENTITY

}
