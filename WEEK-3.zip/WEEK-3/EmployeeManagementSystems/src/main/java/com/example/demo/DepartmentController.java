package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departments")
public class DepartmentController {

    @SuppressWarnings("rawtypes")
	@Autowired
    private DepartmentRepository departmentRepository;

    @SuppressWarnings("unchecked")
	@GetMapping
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    @SuppressWarnings("unchecked")
	@PostMapping
    public Department createDepartment(@RequestBody Department department) {
        return (Department) departmentRepository.save(department);
    }

    @SuppressWarnings("unchecked")
	@GetMapping("/{id}")
    public Department getDepartmentById(@PathVariable Long id) {
        return (Department) departmentRepository.findById(id).orElse(null);
    }

    @SuppressWarnings("unchecked")
	@DeleteMapping("/{id}")
    public void deleteDepartment(@PathVariable Long id) {
        departmentRepository.deleteById(id);
    }
}
