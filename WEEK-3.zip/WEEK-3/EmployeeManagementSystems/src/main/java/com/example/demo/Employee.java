package com.example.demo;



import javax.annotation.processing.Generated;

@Entity
public class Employee {

    @jakarta.persistence.Id
    @Generated(comments = GenerationType.IDENTITY, value = { "" })
    private Long id;

    private String name;
    private String email;
}



