package com.example.demo;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Method with pagination support
    Page<Employee> findByDepartmentName(String departmentName, org.springframework.data.domain.Pageable pageable);

    // Method with pagination support for partial name search
    Page<Employee> findByNameContaining(String name, org.springframework.data.domain.Pageable pageable);
}

