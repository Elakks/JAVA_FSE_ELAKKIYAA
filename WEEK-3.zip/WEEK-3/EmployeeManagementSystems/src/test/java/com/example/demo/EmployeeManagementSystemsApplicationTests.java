package com.example.demo;

@SpringBootApplication
@EnableJpaAuditing
class EmployeeManagementSystemsApplicationTests {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementSystemApplicationTests.class, args);
    }
}

    
