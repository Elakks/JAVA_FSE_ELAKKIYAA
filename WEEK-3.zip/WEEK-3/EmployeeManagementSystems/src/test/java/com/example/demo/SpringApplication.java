package com.example.demo;

public class SpringApplication {

	public static void run1(Class<EmployeeManagementSystemApplicationTests> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}

	public static void run11(Class<EmployeeManagementSystemApplicationTests> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}

	public static void run(Class<EmployeeManagementSystemApplicationTests> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}

}
