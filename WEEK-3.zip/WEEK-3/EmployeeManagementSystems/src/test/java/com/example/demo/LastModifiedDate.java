package com.example.demo;

public @interface LastModifiedDate {

}
