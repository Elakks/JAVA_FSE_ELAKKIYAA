package com.example.BookstoreAPI;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {
    @SuppressWarnings("unused")
	private Long id;
    @SuppressWarnings("unused")
	private String title;
    @SuppressWarnings("unused")
	private String author;
    @SuppressWarnings("unused")
	private Double price;
    @SuppressWarnings("unused")
	private String isbn;
	public Book() {
		// TODO Auto-generated constructor stub
	}
	public Book(long l, String string, String string2, double d, String string3) {
		// TODO Auto-generated constructor stub
	}
	public void setId(long l) {
		// TODO Auto-generated method stub
		
	}
	public String getAuthor() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}
}


