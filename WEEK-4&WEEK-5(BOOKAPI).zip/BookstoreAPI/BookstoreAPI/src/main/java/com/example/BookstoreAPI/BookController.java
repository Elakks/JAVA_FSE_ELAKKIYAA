package com.example.BookstoreAPI;


import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @GetMapping
    public List<Book> getAllBooks() {
        return List.of(
            new Book(),
            new Book()
        );
    }

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        book.setId(3L); // Simulated ID assignment
        return book;
    }

    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book book) {
        book.setId(id);
        return book;
    }

    @DeleteMapping("/{id}")
    public String deleteBook(@PathVariable Long id) {
        return "Book with ID " + id + " deleted successfully";
    }
    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Long id) {
        // Placeholder logic; replace with actual data fetching logic
        if (id == 1L) {
            return new Book(1L, "The Great Gatsby", "F. Scott Fitzgerald", 10.99, "9780743273565");
        } else if (id == 2L) {
            return new Book(2L, "1984", "George Orwell", 8.99, "9780451524935");
        } else {
            throw new RuntimeException("Book not found with ID " + id);
        }
    }
    @GetMapping("/search")
    public List<Book> searchBooks(
        @RequestParam(required = false) String title,
        @RequestParam(required = false) String author
    ) {
        // Placeholder logic; replace with actual filtering logic
        List<Book> books = List.of(
            new Book(1L, "The Great Gatsby", "F. Scott Fitzgerald", 10.99, "9780743273565"),
            new Book(2L, "1984", "George Orwell", 8.99, "9780451524935"),
            new Book(3L, "To Kill a Mockingbird", "Harper Lee", 12.99, "9780061120084")
        );

        // Filtering logic based on query parameters
        return books.stream()
            .filter(book -> (title == null || book.getTitle().equalsIgnoreCase(title)) &&
                            (author == null || book.getAuthor().equalsIgnoreCase(author)))
            .toList();
    }


}
