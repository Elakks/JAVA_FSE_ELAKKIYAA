package com.example.BookstoreAPI;

public interface Mappers {

	static BookMapper getMapper(Class<BookMapper> class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
