package com.example.BookstoreAPI;

@Mapper
public interface BookMapper {
    BookMapper INSTANCE = Mappers.getMapper(BookMapper.class);

    Book toBookDTO(Book book);
    Book toBook(Book bookDTO);
}


