package com.example.BookstoreAPI;

public @interface Mapper {

}
