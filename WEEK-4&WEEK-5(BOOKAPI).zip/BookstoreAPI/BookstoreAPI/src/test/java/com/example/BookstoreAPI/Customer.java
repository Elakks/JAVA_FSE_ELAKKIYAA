package com.example.BookstoreAPI;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
    public Customer(long l, String name2, String email2, String password2) {
		// TODO Auto-generated constructor stub
	}
	@SuppressWarnings("unused")
	private Long id;
    @SuppressWarnings("unused")
	private String name;
    @SuppressWarnings("unused")
	private String email;
    @SuppressWarnings("unused")
	private String password;
	public void setId(long l) {
		// TODO Auto-generated method stub
		
	}
}



