package com.example.BookstoreAPI;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookDTO {
    @SuppressWarnings("unused")
	private Long id;
    @SuppressWarnings("unused")
	private String title;
    @SuppressWarnings("unused")
	private String author;
    @SuppressWarnings("unused")
	private double price;
    @SuppressWarnings("unused")
	private String isbn;
}

