package com.example.BookstoreAPI;



import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        customer.setId(1L); // Simulate setting an ID
        return customer;
    }

    @PostMapping("/register")
    public Customer registerCustomer(
        @RequestParam String name,
        @RequestParam String email,
        @RequestParam String password
    ) {
        return new Customer(2L, name, email, password);
    }
}

