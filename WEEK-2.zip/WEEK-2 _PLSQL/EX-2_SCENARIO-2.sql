DROP TABLE customers CASCADE CONSTRAINTS;
-- Create table
CREATE TABLE Employees (
  id NUMBER PRIMARY KEY,
  salary NUMBER
);

-- Insert sample data
INSERT INTO Employees (id, salary)
VALUES
  (1, 50000),
  (2, 60000);

-- Stored procedure
CREATE OR REPLACE PROCEDURE UpdateSalary(
  p_employee_id NUMBER,
  p_percentage NUMBER
) IS
BEGIN
  BEGIN
    -- Check if employee exists
    IF NOT EXISTS (SELECT 1 FROM Employees WHERE id = p_employee_id) THEN
      RAISE_APPLICATION_ERROR(-20004, 'Employee does not exist');
    END IF;

    -- Update salary
    UPDATE Employees
    SET salary = salary + (salary * p_percentage / 100)
    WHERE id = p_employee_id;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
RAISE;
  END;
END;
/
