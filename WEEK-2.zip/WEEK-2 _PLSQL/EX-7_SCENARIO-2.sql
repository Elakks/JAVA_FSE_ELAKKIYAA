CREATE OR REPLACE PACKAGE EmployeeManagement AS
  PROCEDURE HireEmployee(p_employee_id NUMBER, p_name VARCHAR2, p_salary NUMBER);
  PROCEDURE UpdateEmployeeDetails(p_employee_id NUMBER, p_name VARCHAR2, p_salary NUMBER);
  FUNCTION CalculateAnnualSalary(p_employee_id NUMBER) RETURN NUMBER;
END EmployeeManagement;

CREATE OR REPLACE PACKAGE BODY EmployeeManagement AS
  PROCEDURE HireEmployee(p_employee_id NUMBER, p_name VARCHAR2, p_salary NUMBER) IS
  BEGIN
    INSERT INTO Employees (id, name, salary) VALUES (p_employee_id, p_name, p_salary);
  END;

  PROCEDURE UpdateEmployeeDetails(p_employee_id NUMBER, p_name VARCHAR2, p_salary NUMBER) IS
  BEGIN
    UPDATE Employees SET name = p_name, salary = p_salary WHERE id = p_employee_id;
  END;

  FUNCTION CalculateAnnualSalary(p_employee_id NUMBER) RETURN NUMBER IS
    v_salary NUMBER;
  BEGIN
    SELECT salary INTO v_salary FROM Employees WHERE id = p_employee_id;
    RETURN v_salary * 12;
  END;
END EmployeeManagement;
