DROP TABLE customers CASCADE CONSTRAINTS;
CREATE OR REPLACE PROCEDURE TransferFunds(
  p_source_account NUMBER,
  p_target_account NUMBER,
  p_amount NUMBER
) IS
  v_source_balance NUMBER;
BEGIN
  SELECT balance INTO v_source_balance
  FROM Accounts
  WHERE id = p_source_account;

  IF v_source_balance < p_amount THEN
    RAISE_APPLICATION_ERROR(-20006, 'Insufficient funds');
  END IF;

  UPDATE Accounts
  SET balance = balance - p_amount
  WHERE id = p_source_account;

  UPDATE Accounts
  SET balance = balance + p_amount
  WHERE id = p_target_account;
END;
/
