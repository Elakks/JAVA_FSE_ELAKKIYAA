DROP TABLE customers CASCADE CONSTRAINTS;
CREATE OR REPLACE PACKAGE CustomerManagement AS
  PROCEDURE AddCustomer(p_customer_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE);
  PROCEDURE UpdateCustomerDetails(p_customer_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE);
  FUNCTION GetCustomerBalance(p_customer_id NUMBER) RETURN NUMBER;
END CustomerManagement;

CREATE OR REPLACE PACKAGE BODY CustomerManagement AS
  PROCEDURE AddCustomer(p_customer_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE) IS
  BEGIN
    INSERT INTO Customers (id, name, date_of_birth) VALUES (p_customer_id, p_name, p_date_of_birth);
  END;

  PROCEDURE UpdateCustomerDetails(p_customer_id NUMBER, p_name VARCHAR2, p_date_of_birth DATE) IS
  BEGIN
    UPDATE Customers SET name = p_name, date_of_birth = p_date_of_birth WHERE id = p_customer_id;
  END;

  FUNCTION GetCustomerBalance(p_customer_id NUMBER) RETURN NUMBER IS
    v_balance NUMBER;
  BEGIN
    SELECT SUM(balance) INTO v_balance FROM Accounts WHERE customer_id = p_customer_id;
    RETURN v_balance;
  END;
END CustomerManagement;