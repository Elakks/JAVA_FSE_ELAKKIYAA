DROP TABLE customers CASCADE CONSTRAINTS;
-- Create tables
CREATE TABLE Accounts (
  id NUMBER PRIMARY KEY,
  balance NUMBER
);

CREATE TABLE TransferLog (
  id NUMBER PRIMARY KEY,
  error_message VARCHAR2(200)
);

-- Insert sample data
INSERT INTO Accounts (id, balance)
VALUES
  (1, 1000),
  (2, 500);

-- Stored procedure
CREATE OR REPLACE PROCEDURE SafeTransferFunds(
  p_from_account NUMBER,
  p_to_account NUMBER,
  p_amount NUMBER
) IS
BEGIN
  BEGIN
    -- Check if accounts exist
    IF NOT EXISTS (SELECT 1 FROM Accounts WHERE id = p_from_account) THEN
      RAISE_APPLICATION_ERROR(-20001, 'Source account does not exist');
    ELSIF NOT EXISTS (SELECT 1 FROM Accounts WHERE id = p_to_account) THEN
      RAISE_APPLICATION_ERROR(-20002, 'Destination account does not exist');
    END IF;
-- Check if sufficient funds
    IF (SELECT balance FROM Accounts WHERE id = p_from_account) < p_amount THEN
      RAISE_APPLICATION_ERROR(-20003, 'Insufficient funds');
    END IF;

    -- Transfer funds
    UPDATE Accounts
    SET balance = balance - p_amount
    WHERE id = p_from_account;

    UPDATE Accounts
    SET balance = balance + p_amount
    WHERE id = p_to_account;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      INSERT INTO TransferLog (id, error_message)
      VALUES (TransferLog_SEQ.NEXTVAL, SQLERRM);
      RAISE;
  END;
END;
/
