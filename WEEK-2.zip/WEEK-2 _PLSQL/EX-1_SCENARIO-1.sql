-- Create table
CREATE TABLE customers (
  id NUMBER PRIMARY KEY,
  name VARCHAR2(50),
  age NUMBER,
  loan_interest_rate NUMBER
);

-- Insert sample data
INSERT INTO customers (id, name, age, loan_interest_rate)
VALUES
  (1, 'John Doe', 55, 5.5),
  (2, 'Jane Smith', 65, 6.0),
  (3, 'Bob Johnson', 70, 7.0);

-- PL/SQL block
DECLARE
  CURSOR c_customers IS
    SELECT * FROM customers;
BEGIN
  FOR customer IN c_customers LOOP
    IF customer.age > 60 THEN
      UPDATE customers
      SET loan_interest_rate = loan_interest_rate - 1
      WHERE id = (link unavailable);
    END IF;
  END LOOP;
END;
/


