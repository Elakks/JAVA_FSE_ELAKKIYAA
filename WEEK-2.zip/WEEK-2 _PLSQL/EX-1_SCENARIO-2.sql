-- Create table
CREATE TABLE customers (
  id NUMBER PRIMARY KEY,
  name VARCHAR2(50),
  balance NUMBER,
  is_vip BOOLEAN DEFAULT FALSE
);

-- Insert sample data
INSERT INTO customers (id, name, balance)
VALUES
  (1, 'John Doe', 5000),
  (2, 'Jane Smith', 15000),
  (3, 'Bob Johnson', 20000);

-- PL/SQL block
DECLARE
  CURSOR c_customers IS
    SELECT * FROM customers;
BEGIN
  FOR customer IN c_customers LOOP
    IF customer.balance > 10000 THEN
      UPDATE customers
      SET is_vip = TRUE
      WHERE id = (link unavailable);
    END IF;
  END LOOP;
END;
/
