DECLARE
  CURSOR c_accounts IS
    SELECT *
    FROM Accounts;
BEGIN
  FOR account IN c_accounts LOOP
    UPDATE Accounts
    SET balance = balance - 100  -- assuming annual fee is 100
    WHERE id = (link unavailable);
  END LOOP;
END;
/