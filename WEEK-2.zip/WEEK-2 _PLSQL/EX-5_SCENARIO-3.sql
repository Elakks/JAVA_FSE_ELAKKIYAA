CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
BEGIN
  IF :NEW.transaction_type = 'WITHDRAWAL' THEN
    IF :NEW.amount > (SELECT balance FROM Accounts WHERE id = :NEW.account_id) THEN
      RAISE_APPLICATION_ERROR(-20007, 'Insufficient funds');
    END IF;
  ELSIF :NEW.transaction_type = 'DEPOSIT' THEN
    IF :NEW.amount <= 0 THEN
      RAISE_APPLICATION_ERROR(-20008, 'Deposit amount must be positive');
    END IF;
  END IF;
END;
/
