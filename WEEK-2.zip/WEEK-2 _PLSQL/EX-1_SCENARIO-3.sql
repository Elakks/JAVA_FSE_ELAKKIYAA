-- Create table
CREATE TABLE loans (
  id NUMBER PRIMARY KEY,
  customer_id NUMBER,
  due_date DATE,
  loan_amount NUMBER
);

-- Insert sample data
INSERT INTO loans (id, customer_id, due_date, loan_amount)
VALUES
  (1, 1, DATE '2024-09-01', 1000),
  (2, 2, DATE '2024-08-20', 5000),
  (3, 3, DATE '2024-09-15', 2000);

-- PL/SQL block
DECLARE
  CURSOR c_loans IS
    SELECT * FROM loans
    WHERE due_date BETWEEN SYSTIMESTAMP AND SYSTIMESTAMP + INTERVAL '30' DAY;
BEGIN
  FOR loan IN c_loans LOOP
    DBMS_OUTPUT.PUT_LINE('Reminder: Loan ' || (link unavailable) || ' due on ' || loan.due_date);
  END LOOP;
END;
/
