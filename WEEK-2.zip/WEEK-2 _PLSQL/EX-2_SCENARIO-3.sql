DROP TABLE customers CASCADE CONSTRAINTS;
-- Create table
CREATE TABLE Customers (
  id NUMBER PRIMARY KEY,
  name VARCHAR2(50)
);

-- Stored procedure
CREATE OR REPLACE PROCEDURE AddNewCustomer(
  p_customer_id NUMBER,
  p_name VARCHAR2
) IS
BEGIN
  BEGIN
    -- Check if customer already exists
    IF EXISTS (SELECT 1 FROM Customers WHERE id = p_customer_id) THEN
      RAISE_APPLICATION_ERROR(-20005, 'Customer already exists');
    END IF;

    -- Insert new customer
    INSERT INTO Customers (id, name)
    VALUES (p_customer_id, p_name);

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
      RAISE;
  END;
END;
/
