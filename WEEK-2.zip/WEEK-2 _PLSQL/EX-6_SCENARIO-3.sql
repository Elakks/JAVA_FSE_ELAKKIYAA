DECLARE
  CURSOR c_loans IS
    SELECT *
    FROM Loans;
BEGIN
  FOR loan IN c_loans LOOP
    UPDATE Loans
    SET interest_rate = 0.05  -- assuming new interest rate is 5%
    WHERE id = (link unavailable);
  END LOOP;
END;
/
