CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment(
  p_loan_amount NUMBER,
  p_interest_rate NUMBER,
  p_loan_duration NUMBER
) RETURN NUMBER IS
  v_monthly_interest_rate NUMBER;
  v_monthly_installment NUMBER;
BEGIN
  v_monthly_interest_rate := p_interest_rate / 1200;
  v_monthly_installment := p_loan_amount * v_monthly_interest_rate * POWER(1 + v_monthly_interest_rate, p_loan_duration * 12) / (POWER(1 + v_monthly_interest_rate, p_loan_duration * 12) - 1);
  RETURN v_monthly_installment;
END;
/
