DROP TABLE customers CASCADE CONSTRAINTS;
DECLARE
  CURSOR c_transactions IS
    SELECT *
    FROM Transactions
    WHERE EXTRACT(MONTH FROM transaction_date) = EXTRACT(MONTH FROM SYSTIMESTAMP)
    AND EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM SYSTIMESTAMP);
BEGIN
  FOR transaction IN c_transactions LOOP
    DBMS_OUTPUT.PUT_LINE('Statement for customer ' || transaction.customer_id);
    DBMS_OUTPUT.PUT_LINE('Transaction date: ' || transaction.transaction_date);
    DBMS_OUTPUT.PUT_LINE('Amount: ' || transaction.amount);
    DBMS_OUTPUT.PUT_LINE('Balance: ' || (SELECT balance FROM Accounts WHERE id = transaction.account_id));
  END LOOP;
END;
/

