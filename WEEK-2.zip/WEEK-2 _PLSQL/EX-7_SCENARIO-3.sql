CREATE OR REPLACE PACKAGE AccountOperations AS
  PROCEDURE OpenAccount(p_account_id NUMBER, p_customer_id NUMBER, p_initial_balance NUMBER);
  PROCEDURE CloseAccount(p_account_id NUMBER);
  FUNCTION GetTotalBalance(p_customer_id NUMBER) RETURN NUMBER;
END AccountOperations;

CREATE OR REPLACE PACKAGE BODY AccountOperations AS
  PROCEDURE OpenAccount(p_account_id NUMBER, p_customer_id NUMBER, p_initial_balance NUMBER) IS
  BEGIN
    INSERT INTO Accounts (id, customer_id, balance) VALUES (p_account_id, p_customer_id, p_initial_balance);
  END;

  PROCEDURE CloseAccount(p_account_id NUMBER) IS
  BEGIN
    DELETE FROM Accounts WHERE id = p_account_id;
  END;

  FUNCTION GetTotalBalance(p_customer_id NUMBER) RETURN NUMBER IS
    v_balance NUMBER;
  BEGIN
    SELECT SUM(balance) INTO v_balance FROM Accounts WHERE customer_id = p_customer_id;
    RETURN v_balance;
  END;
END AccountOperations;


