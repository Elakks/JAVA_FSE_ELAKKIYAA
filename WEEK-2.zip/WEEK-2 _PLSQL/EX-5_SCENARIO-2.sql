CREATE TABLE AuditLog (
  id NUMBER PRIMARY KEY,
  transaction_id NUMBER,
  transaction_date DATE,
  log_message VARCHAR2(200)
);

CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
  INSERT INTO AuditLog (id, transaction_id, transaction_date, log_message)
  VALUES (AuditLog_SEQ.NEXTVAL, :(link unavailable), SYSTIMESTAMP, 'Transaction inserted');
END;
/
