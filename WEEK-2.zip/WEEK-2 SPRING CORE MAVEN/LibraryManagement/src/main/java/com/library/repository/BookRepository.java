package com.library.repository;

public class BookRepository {
    // This class can have methods to interact with the database
}
